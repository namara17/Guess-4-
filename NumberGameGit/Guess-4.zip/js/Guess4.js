 $(document).ready(function() {    /* Guess-4! Dedicated to my Dad - Dr. William S. Armstrong :) */ 
   $('#commBox').hide();
   $('#feedback').hide();
   $('.guessesLeft').hide();
   $('#winLose').hide();
   $('scratchpad').hide();   
  
   $('#rules').mousedown(function() {
      $('.slideup').slideToggle("slow"); 
   });

   $('#openScratchpad').mousedown(function() {
	  $('#scratchpad').slideToggle('slow');
   });
 outer = "";
 possibles = "<h3>Either ____ or (_or_)</h3>";
 myNum = [];

     $('#commBox').keyup(function(e) {
    	//alert(e.keyCode);
    	if(e.keyCode == 13) {	
            newGuess();
    	}
    });
 
  $('#numline p').click(function(event){	 
    that = this; 
	   if ( $(that).hasClass('highlight')){
          $(that).removeClass('highlight');
	    } else if ( $(that).hasClass('xout')){
          $(that).removeClass('xout');   
        } else if ($(that).hasClass('circle')) {
		  $(that).removeClass('circle'); 			   
        } else {
		  $(that).addClass("highlight");
        }
	   return that;
     })

   $('#xout').click(function(event){		 
   	  $(that).removeClass('highlight');
	  $(that).addClass('xout');
	   that= null;
     })

   $('#circle').click(function(event){		 
  	  //  IFF    if(event.target.parent().parent('div').closest().id === "numline") {}
	  $(that).removeClass('highlight');
	  $(that).addClass('circle');
	  that=null;
   });
 

 	/* Delete Scratchpad Line or Insert Scratchpad Number */
  $('#scratchpad').click(function(event) {
 if (event.target.id !="numline") 
  {
  if (event.target.className === "blanks") {
     insertnum(event);
	 return false;
  }																		
  else if (event.target.className === "del") {
    $(event.target).parent().detach();			              
    return false;
  }
  else if (event.target.className === "plus")
  {	 plusPossible(event);
     return false;
  }
}
 });

})	 // ------ Close document ready code ----- //


function plusPossible(event) {
  thatPlus = event.target;
  if ($(thatPlus).parent().parent('div')[0].id === "possible") 
  	 { $('#possible').append("<div><span class='del' onclick='gone(event)'></span><p><div class='blanks'></div><div class='blanks'></div><div class='blanks'></div><div class='blanks'></div></p></div>");  
	 } 
	 else {
	$('#possright').append("<div><span class='del' onclick='gone(event)'></span><div class='or'><span>(</span><div class='blanks'></div><span>or</span><div class='blanks'></div><span>)</span></div></div>"); 
    }
 }


 function newGame() {
	 /* Reset Game Parameters */
 $('body').removeClass('winners');
// $('#rules').show();
 $('#commBox').show();
 $('#feedback').show();
 $('#winLose').hide().html("<h2> X </h2>");
 $('.guessesLeft').show().text(" 12 Guesses Left");
 $('#scratchpad').hide();
 $('.blanks').text("");
 $('#numline>p').removeClass(); 
 $('.del').parent('div').not(':eq(0)').detach();
 document.getElementById('nextGuess').value = "";
 document.getElementById('feedback').innerHTML = "<p><u>Your Score:</u></p></div>";
 var y=0;		 
 remaining = 12;

   /****  Begin Setting up Game  *****/
 myNum =[ Math.floor(Math.random()*10),0,0,0];
 myNum2 = "";
   for (var i=1; i<4; i++)
     {
     y = Math.floor(Math.random()*10); 
     for (var k=0; k<i; k++)
	    {
         if (y === myNum[k])
	       {
	       i--;
		   k=14;
           }
		 else 
	       { 
		   (myNum[i]=y);
           }
        }				 
     }
   myNum.length=4;
     for(z=0;z <= 3; z++)
	   {
	   x = myNum[z].toString();
	   myNum2 += x;
	   }
   return myNum;
  }	      // $('#commBox h4').append("myNum2 = " + myNum2); - for Debugging

/* --------------------------------	*/


 function insertnum(event){  
     thatBlank = event.target;
	 var scratchInput =0;
	
	 if (!$(thatBlank).text()) {		 
   	     $(thatBlank).closest('div.blanks').append("<input type='text' name='tempInput' id='tempInput'   style='background:rgb(220,220,240);width:24px;height:24px;' onclick=\"insertNum(event)\">");
		 $('#tempInput').focus().select();	   // This sets the cursor inside.
  	
		$(thatBlank).keypress(function(event) {
		   xx = (event.keyCode || event.charCode);	
	       scratchInput = xx - 48;	  // subtr. 48 for keycode
		   $('#tempInput').remove();  
		   $(thatBlank).text(scratchInput); 
		   return scratchInput;
		   });		 // close keypress function.
	   } 
      else if ($(thatBlank).closest('div.blanks').text())
	     { $(thatBlank).closest('div.blanks').text("");   // Blank out the text.
	     } 
  }


/* --------------------------------	*/

 function gone(event) {
   $(event.target).parent().remove();
 }


 function winnerCircle() {
	var msg="Congratulations!" + " " + " You guessed my number!";
    if (remaining >4)
       {
  	   msg = " TERRIFIC job! "+ " " +" You guessed my number in "+(12 - remaining)+ " guesses!";
       }
	$('#winLose').show().append(msg); 
	$('#winLose').append("<br /><span class=\"bigger\">" + myNum2 + "</span>"); 
    $('body').toggleClass('winners');

	$('#winLose h2').mouseup(function(){
	   $('#winLose').html('<h2> X </h2>').hide();
	   $('body').toggleClass('winners');
	    newGame(); 
	  })   //  end X - click function

	}  // end WinnerCircle

 function gameOver(){
 msg= "Sorry, you used up your 12 guesses.<br />My number was  " + myNum2 +"<br /><br />Do you want to try again?  <strong><span class=\"yes\">| Yes </span> /  <span class=\"no\"> No |</span></strong></h3><br />";
	$('#winLose').append(msg).show('slow'); 
    $('body').toggleClass('winners');
  $('.yes').click(function() {
	   newGame();
    })
  $('.no').click(function() {
      msg = "THANKS FOR PLAYING!";
      $('#winLose').toggleClass('over').text(msg);
	  $('body').addClass('over').css('color','purple'); 
      setTimeout(function() { $('body').fadeOut('slow') },3000);
 	 }) 
  }   //   end of gameOver

  //begin main loop with remaining guesses.
 function newGuess() {
	$('#commBox h4.red').remove();
	var userGuessArray = [];
	var userGuessed = document.getElementById('nextGuess').value;

 if ( isNaN(+userGuessed) || +userGuessed %1 != 0 || +userGuessed > 9876 || +userGuessed < 0123)
    {  
	 $('#commBox input:last').after("<h4 class='red'>Please enter a 4-digit number, with no spaces and no duplicates</h4>"); 
	  document.getElementById('nextGuess').value = "";
	  return;
    }

  for (j=0; j<4; j++)
	  {	
	  userGuessArray[j] = +userGuessed[j]; 
	  }				

     // EVALUATE USER GUESS

      npicas = nforms = 0;     
      for (var m=0; m<4 ; m++)
        {
        for (var loop=0; loop<4; loop++)
           {   
	       if (myNum[m] === userGuessArray[loop])	  // test the array format of userGuess which is
              {
	          (m === loop)? nforms++ : npicas++;
              }
           }
  	     }

	  remaining--;
	  document.getElementById('nextGuess').value = "";
 	  if (nforms === 4)
  	     {
		  winnerCircle(); 
		 }
	

		  // tell player results of guess
	  $('#feedback').append("<p> " + userGuessed + "  - " + nforms + " Form, " + npicas + " Pica </p>");	 // output the number format
      $('.guessesLeft').text(" " + remaining + " guesses left! ");

	  if (remaining < 1)
	    { gameOver(newGame());	  // callback function newGame
	    }
 
  }   //  End function newGuess

  /*
  TUTORIAL
  1. If you want to see how to place CURSOR in an <input> box, see line 143  $('').focus().select();  
  2. How to detect ENTER keypress -   lines  19-21;
  3. To get VALUE of <input> box  -   lines  203,  145-147;
  4. Onclick to toggle multiple highlights / overlay images  -  lines 26 - 51;
  5. How to 'attach' an event handler to newly added elements - - After months of searching and trial & error (much error), and thanks to the wonderful people on Stackoverflow, here's the gist of the issue:  You have to SELECT an ancestor element that was present when the document was loaded, and then test for which newly added descendant element was actually clicked on - - using  EVENT.TARGET.ID   (or .className)  -  Lines 55 - 72
  6. Generate a random 4-digit number with no duplicates (maybe not the most concise code...) -   Lines 107 - 132
  7. Test one 4-digit number against another  -  Lines 219 - 236
  */